package home.project.exceptions.exception;

public class AddressSearchException extends RuntimeException {
    public AddressSearchException(String message) {
        super(message);
    }
}
