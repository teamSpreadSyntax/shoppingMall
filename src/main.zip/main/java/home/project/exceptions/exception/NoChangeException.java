package home.project.exceptions.exception;

public class NoChangeException extends RuntimeException {
    public NoChangeException(String message) {
        super(message);
    }
}
