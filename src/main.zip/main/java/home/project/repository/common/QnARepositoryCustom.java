package home.project.repository.common;

public interface QnARepositoryCustom {

}