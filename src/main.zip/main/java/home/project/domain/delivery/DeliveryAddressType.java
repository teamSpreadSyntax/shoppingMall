package home.project.domain.delivery;

public enum DeliveryAddressType {
    DEFAULT_ADDRESS,
    NEW_ADDRESS,
}
