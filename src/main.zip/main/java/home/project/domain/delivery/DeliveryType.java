package home.project.domain.delivery;

public enum DeliveryType {
    STRAIGHT_DELIVERY,
    ORDINARY_DELIVERY,
    REMOTE_DELIVERY
}
