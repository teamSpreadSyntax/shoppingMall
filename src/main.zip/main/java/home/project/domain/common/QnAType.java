package home.project.domain.common;

public enum QnAType {
    SHIPPING,
    ORDER,
    REFUND,
    OTHER
}
