package home.project.domain.member;

public enum MemberGradeType {

    BRONZE, SILVER, GOLD, PLATINUM

}
