package home.project.domain.member;

public enum MemberGenderType {

        M, F, N

}
