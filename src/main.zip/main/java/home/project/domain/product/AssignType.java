package home.project.domain.product;

public enum AssignType {
    SPECIFIC_PRODUCTS,
    SPECIFIC_MEMBERS,
    ALL
}
